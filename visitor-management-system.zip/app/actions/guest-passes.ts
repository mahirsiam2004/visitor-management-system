'use server'

import { createClient } from '@/lib/supabase/server'
import { generateQRToken, generateGuestId, calculateExpiryTime, isPassExpired } from '@/lib/utils/guest-pass'
import { createGuestPassSchema, checkInGuestSchema, checkOutGuestSchema } from '@/lib/validations/schemas'
import { revalidatePath } from 'next/cache'

export async function createGuestPass(input: unknown) {
  try {
    const validatedInput = createGuestPassSchema.parse(input)
    const supabase = await createClient()

    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) throw new Error('User not authenticated')

    // Get user's apartment number
    const { data: profile } = await supabase.from('profiles').select('apartment_number').eq('id', user.id).single()

    if (!profile?.apartment_number) throw new Error('Apartment number not found in profile')

    const guestId = generateGuestId()
    const qrToken = generateQRToken()
    const expiryTime = calculateExpiryTime(validatedInput.visitDate, validatedInput.visitTime, validatedInput.durationHours)

    const { data, error } = await supabase.from('guest_passes').insert({
      guest_id: guestId,
      guest_name: validatedInput.guestName,
      guest_phone: validatedInput.guestPhone,
      resident_id: user.id,
      apartment_number: profile.apartment_number,
      visit_date: validatedInput.visitDate,
      visit_time: validatedInput.visitTime,
      expiry_time: expiryTime.toISOString(),
      duration_hours: validatedInput.durationHours,
      purpose: validatedInput.purpose,
      qr_token: qrToken,
      status: 'valid',
    }).select()

    if (error) throw error

    revalidatePath('/dashboard/resident')
    revalidatePath('/dashboard/admin')

    return { success: true, data: data?.[0] }
  } catch (error: any) {
    return { success: false, error: error.message }
  }
}

export async function getGuestPasses(filters?: { status?: string; residentId?: string }) {
  try {
    const supabase = await createClient()

    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) throw new Error('User not authenticated')

    // Get user's role
    const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single()

    let query = supabase.from('guest_passes').select('*').order('created_at', { ascending: false })

    // Apply filters based on user role
    if (profile?.role === 'resident') {
      query = query.eq('resident_id', user.id)
    } else if (filters?.residentId) {
      query = query.eq('resident_id', filters.residentId)
    }

    if (filters?.status) {
      query = query.eq('status', filters.status)
    }

    const { data, error } = await query

    if (error) throw error

    return { success: true, data }
  } catch (error: any) {
    return { success: false, error: error.message }
  }
}

export async function updateGuestPassStatus(guestPassId: string, status: 'valid' | 'expired' | 'revoked') {
  try {
    const supabase = await createClient()

    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) throw new Error('User not authenticated')

    // Check if user is admin or the pass owner
    const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single()
    const { data: guestPass } = await supabase.from('guest_passes').select('resident_id').eq('id', guestPassId).single()

    if (profile?.role !== 'admin' && guestPass?.resident_id !== user.id) {
      throw new Error('Unauthorized')
    }

    const { error } = await supabase.from('guest_passes').update({ status }).eq('id', guestPassId)

    if (error) throw error

    revalidatePath('/dashboard/resident')
    revalidatePath('/dashboard/admin')

    return { success: true }
  } catch (error: any) {
    return { success: false, error: error.message }
  }
}

export async function checkInGuest(input: unknown) {
  try {
    const validatedInput = checkInGuestSchema.parse(input)
    const supabase = await createClient()

    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) throw new Error('User not authenticated')

    // Verify user is security guard or admin
    const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single()

    if (!['security', 'admin'].includes(profile?.role || '')) {
      throw new Error('Only security guards can check in guests')
    }

    // Find guest pass by guest_id and qr_token
    const { data: guestPass } = await supabase
      .from('guest_passes')
      .select('*')
      .eq('guest_id', validatedInput.guestId)
      .eq('qr_token', validatedInput.qrToken)
      .single()

    if (!guestPass) throw new Error('Invalid guest pass')

    // Check if pass is expired or revoked
    if (guestPass.status !== 'valid' || isPassExpired(guestPass.expiry_time)) {
      throw new Error('Guest pass is no longer valid')
    }

    // Create entry log
    const { data: entryLog, error } = await supabase
      .from('entry_logs')
      .insert({
        guest_pass_id: guestPass.id,
        security_guard_id: user.id,
        entry_time: new Date().toISOString(),
        status: 'inside',
      })
      .select()

    if (error) throw error

    revalidatePath('/dashboard/security')
    revalidatePath('/dashboard/admin')

    return { success: true, data: entryLog?.[0] }
  } catch (error: any) {
    return { success: false, error: error.message }
  }
}

export async function checkOutGuest(input: unknown) {
  try {
    const validatedInput = checkOutGuestSchema.parse(input)
    const supabase = await createClient()

    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) throw new Error('User not authenticated')

    // Verify user is security guard or admin
    const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single()

    if (!['security', 'admin'].includes(profile?.role || '')) {
      throw new Error('Only security guards can check out guests')
    }

    // Update entry log
    const { error } = await supabase
      .from('entry_logs')
      .update({
        exit_time: new Date().toISOString(),
        status: 'completed',
      })
      .eq('id', validatedInput.entryLogId)

    if (error) throw error

    revalidatePath('/dashboard/security')
    revalidatePath('/dashboard/admin')

    return { success: true }
  } catch (error: any) {
    return { success: false, error: error.message }
  }
}

export async function deleteGuestPass(guestPassId: string) {
  try {
    const supabase = await createClient()

    const {
      data: { user },
    } = await supabase.auth.getUser()
    if (!user) throw new Error('User not authenticated')

    // Check if user is admin
    const { data: profile } = await supabase.from('profiles').select('role').eq('id', user.id).single()

    if (profile?.role !== 'admin') {
      throw new Error('Only admins can delete guest passes')
    }

    const { error } = await supabase.from('guest_passes').delete().eq('id', guestPassId)

    if (error) throw error

    revalidatePath('/dashboard/admin')

    return { success: true }
  } catch (error: any) {
    return { success: false, error: error.message }
  }
}
