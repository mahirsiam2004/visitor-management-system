'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { CheckCircle, Mail } from 'lucide-react'

export default function SignUpSuccessPage() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="w-full max-w-md text-center">
        {/* Icon */}
        <div className="mb-6">
          <div className="flex justify-center">
            <CheckCircle className="w-16 h-16 text-green-500" />
          </div>
        </div>

        {/* Message */}
        <h1 className="text-3xl font-bold text-slate-900 mb-4">Account Created!</h1>
        <p className="text-slate-600 mb-6">
          Your account has been created successfully. Please check your email to confirm your account before logging in.
        </p>

        {/* Email Icon */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <Mail className="w-6 h-6 text-blue-600 mx-auto mb-2" />
          <p className="text-sm text-blue-700">Check your inbox for a confirmation email</p>
        </div>

        {/* CTA */}
        <div className="space-y-3">
          <Link href="/auth/login" className="block">
            <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white">
              Return to Login
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}
