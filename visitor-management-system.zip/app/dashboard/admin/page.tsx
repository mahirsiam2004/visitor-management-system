'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { LogOut, Users, FileText, Clock } from 'lucide-react'
import { toast } from 'sonner'
import AdminHeader from '@/components/AdminHeader'

interface AdminStats {
  totalUsers: number
  totalGuestPasses: number
  activeGuests: number
  completedVisits: number
}

interface GuestPass {
  id: string
  guest_id: string
  guest_name: string
  resident_id: string
  apartment_number: string
  visit_date: string
  visit_time: string
  duration_hours: number
  purpose: string
  status: 'valid' | 'expired' | 'revoked'
  created_at: string
}

export default function AdminDashboard() {
  const router = useRouter()
  const supabase = createClient()
  const [user, setUser] = useState<any>(null)
  const [stats, setStats] = useState<AdminStats>({
    totalUsers: 0,
    totalGuestPasses: 0,
    activeGuests: 0,
    completedVisits: 0,
  })
  const [recentPasses, setRecentPasses] = useState<GuestPass[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const checkAuth = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push('/auth/login')
        return
      }

      // Get user profile
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single()

      if (profile?.role !== 'admin') {
        router.push('/dashboard/resident')
        return
      }

      setUser(user)
      fetchStats()
      fetchRecentPasses()
    }

    checkAuth()
  }, [])

  const fetchStats = async () => {
    try {
      // Get total users
      const { count: userCount } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })

      // Get total guest passes
      const { data: passes } = await supabase.from('guest_passes').select('*')
      const { count: passCount } = await supabase
        .from('guest_passes')
        .select('*', { count: 'exact', head: true })

      // Get active guests (inside)
      const { count: activeCount } = await supabase
        .from('entry_logs')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'inside')

      // Get completed visits
      const { count: completedCount } = await supabase
        .from('entry_logs')
        .select('*', { count: 'exact', head: true })
        .eq('status', 'completed')

      setStats({
        totalUsers: userCount || 0,
        totalGuestPasses: passCount || 0,
        activeGuests: activeCount || 0,
        completedVisits: completedCount || 0,
      })
    } catch (error: any) {
      toast.error('Failed to load statistics')
    }
  }

  const fetchRecentPasses = async () => {
    try {
      const { data, error } = await supabase
        .from('guest_passes')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10)

      if (error) throw error

      setRecentPasses(data || [])
    } catch (error: any) {
      toast.error('Failed to load guest passes')
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut()
      router.push('/auth/login')
    } catch (error: any) {
      toast.error('Failed to logout')
    }
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <AdminHeader user={user} onLogout={handleLogout} />

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900">System Dashboard</h1>
          <p className="text-slate-600 mt-2">Overview and management of all system activities</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          {/* Total Users */}
          <div className="bg-white rounded-lg border border-slate-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-600 text-sm font-medium">Total Users</p>
                <p className="text-3xl font-bold text-slate-900 mt-2">{stats.totalUsers}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <Users className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </div>

          {/* Total Guest Passes */}
          <div className="bg-white rounded-lg border border-slate-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-600 text-sm font-medium">Guest Passes</p>
                <p className="text-3xl font-bold text-slate-900 mt-2">{stats.totalGuestPasses}</p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </div>

          {/* Active Guests */}
          <div className="bg-white rounded-lg border border-slate-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-600 text-sm font-medium">Inside Now</p>
                <p className="text-3xl font-bold text-slate-900 mt-2">{stats.activeGuests}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <Clock className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>

          {/* Completed Visits */}
          <div className="bg-white rounded-lg border border-slate-200 p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-slate-600 text-sm font-medium">Completed Visits</p>
                <p className="text-3xl font-bold text-slate-900 mt-2">{stats.completedVisits}</p>
              </div>
              <div className="w-12 h-12 bg-amber-100 rounded-lg flex items-center justify-center">
                <FileText className="w-6 h-6 text-amber-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Recent Guest Passes */}
        <div className="bg-white rounded-lg border border-slate-200 p-6">
          <h2 className="text-xl font-semibold text-slate-900 mb-4">Recent Guest Passes</h2>

          {loading ? (
            <div className="text-center py-8">
              <p className="text-slate-600">Loading guest passes...</p>
            </div>
          ) : recentPasses.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-slate-600">No guest passes yet</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-slate-200">
                    <th className="text-left py-3 px-4 font-medium text-slate-900">Guest Name</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-900">Apartment</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-900">Visit Date</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-900">Purpose</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-900">Duration</th>
                    <th className="text-left py-3 px-4 font-medium text-slate-900">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {recentPasses.map((pass) => (
                    <tr key={pass.id} className="border-b border-slate-200 hover:bg-slate-50">
                      <td className="py-3 px-4 text-slate-900">{pass.guest_name}</td>
                      <td className="py-3 px-4 text-slate-600">Apt {pass.apartment_number}</td>
                      <td className="py-3 px-4 text-slate-600">{pass.visit_date}</td>
                      <td className="py-3 px-4 text-slate-600">{pass.purpose}</td>
                      <td className="py-3 px-4 text-slate-600">{pass.duration_hours}h</td>
                      <td className="py-3 px-4">
                        <span
                          className={`text-xs font-medium px-2 py-1 rounded ${
                            pass.status === 'valid'
                              ? 'bg-green-100 text-green-800'
                              : pass.status === 'expired'
                              ? 'bg-yellow-100 text-yellow-800'
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {pass.status.toUpperCase()}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
