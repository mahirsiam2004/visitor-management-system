'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { LogOut, Smartphone } from 'lucide-react'
import { toast } from 'sonner'
import QRScanner from '@/components/QRScanner'
import EntryLogsList from '@/components/EntryLogsList'
import SecurityHeader from '@/components/SecurityHeader'

export default function SecurityDashboard() {
  const router = useRouter()
  const supabase = createClient()
  const [user, setUser] = useState<any>(null)
  const [showScanner, setShowScanner] = useState(false)
  const [loading, setLoading] = useState(true)
  const [entryLogs, setEntryLogs] = useState<any[]>([])

  useEffect(() => {
    const checkAuth = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push('/auth/login')
        return
      }

      // Get user profile
      const { data: profile } = await supabase.from('profiles').select('*').eq('id', user.id).single()

      if (!['security', 'admin'].includes(profile?.role || '')) {
        router.push('/dashboard/resident')
        return
      }

      setUser(user)
      fetchEntryLogs()
    }

    checkAuth()
  }, [])

  const fetchEntryLogs = async () => {
    try {
      const { data, error } = await supabase
        .from('entry_logs')
        .select('*, guest_pass:guest_pass_id(guest_name, guest_id, apartment_number, purpose, guest_phone), guard:security_guard_id(full_name)')
        .order('created_at', { ascending: false })
        .limit(20)

      if (error) throw error

      setEntryLogs(data || [])
    } catch (error: any) {
      toast.error('Failed to load entry logs')
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut()
      router.push('/auth/login')
    } catch (error: any) {
      toast.error('Failed to logout')
    }
  }

  const handleScanSuccess = () => {
    fetchEntryLogs()
    toast.success('Guest checked in successfully!')
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <SecurityHeader user={user} onLogout={handleLogout} />

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header with Scanner Button */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Check-in/out</h1>
            <p className="text-slate-600 mt-2">Scan QR codes to manage guest entry</p>
          </div>
          <Button
            onClick={() => setShowScanner(!showScanner)}
            className="bg-blue-600 hover:bg-blue-700 text-white gap-2"
          >
            <Smartphone className="w-4 h-4" />
            {showScanner ? 'Close Scanner' : 'Open Scanner'}
          </Button>
        </div>

        {/* QR Scanner */}
        {showScanner && (
          <div className="mb-8">
            <QRScanner onSuccess={handleScanSuccess} />
          </div>
        )}

        {/* Entry Logs */}
        <div className="space-y-4">
          <h2 className="text-xl font-semibold text-slate-900">Recent Activity</h2>
          {loading ? (
            <div className="text-center py-12">
              <p className="text-slate-600">Loading entry logs...</p>
            </div>
          ) : entryLogs.length === 0 ? (
            <div className="text-center py-12 bg-white rounded-lg border border-slate-200">
              <p className="text-slate-600">No entry logs yet</p>
            </div>
          ) : (
            <EntryLogsList logs={entryLogs} onUpdate={fetchEntryLogs} />
          )}
        </div>
      </main>
    </div>
  )
}
