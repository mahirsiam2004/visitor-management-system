'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Button } from '@/components/ui/button'
import { Plus, LogOut } from 'lucide-react'
import { toast } from 'sonner'
import CreateGuestPassForm from '@/components/CreateGuestPassForm'
import GuestPassCard from '@/components/GuestPassCard'
import ResidentHeader from '@/components/ResidentHeader'

interface GuestPass {
  id: string
  guest_id: string
  guest_name: string
  guest_phone?: string
  apartment_number: string
  visit_date: string
  visit_time: string
  expiry_time: string
  duration_hours: number
  purpose: string
  qr_token: string
  status: 'valid' | 'expired' | 'revoked'
  created_at: string
}

export default function ResidentDashboard() {
  const router = useRouter()
  const supabase = createClient()
  const [user, setUser] = useState<any>(null)
  const [guestPasses, setGuestPasses] = useState<GuestPass[]>([])
  const [loading, setLoading] = useState(true)
  const [showForm, setShowForm] = useState(false)

  useEffect(() => {
    const checkAuth = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push('/auth/login')
        return
      }

      // Get user profile
      const { data: profile } = await supabase.from('profiles').select('*').eq('id', user.id).single()

      if (profile?.role !== 'resident') {
        router.push('/dashboard/security')
        return
      }

      setUser(user)
      fetchGuestPasses(user.id)
    }

    checkAuth()
  }, [])

  const fetchGuestPasses = async (userId: string) => {
    try {
      const { data, error } = await supabase.from('guest_passes').select('*').eq('resident_id', userId).order('created_at', { ascending: false })

      if (error) throw error

      setGuestPasses(data || [])
    } catch (error: any) {
      toast.error('Failed to load guest passes')
    } finally {
      setLoading(false)
    }
  }

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut()
      router.push('/auth/login')
    } catch (error: any) {
      toast.error('Failed to logout')
    }
  }

  const handlePassCreated = () => {
    setShowForm(false)
    if (user) {
      fetchGuestPasses(user.id)
    }
    toast.success('Guest pass created successfully!')
  }

  if (!user) return null

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      <ResidentHeader user={user} onLogout={handleLogout} />

      <main className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header with Create Button */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-slate-900">Guest Passes</h1>
            <p className="text-slate-600 mt-2">Manage and track your visitor passes</p>
          </div>
          <Button
            onClick={() => setShowForm(!showForm)}
            className="bg-blue-600 hover:bg-blue-700 text-white gap-2"
          >
            <Plus className="w-4 h-4" />
            Create Pass
          </Button>
        </div>

        {/* Create Form */}
        {showForm && <CreateGuestPassForm onSuccess={handlePassCreated} />}

        {/* Guest Passes List */}
        {loading ? (
          <div className="text-center py-12">
            <p className="text-slate-600">Loading guest passes...</p>
          </div>
        ) : guestPasses.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-lg border border-slate-200">
            <p className="text-slate-600 mb-4">No guest passes yet</p>
            <Button
              onClick={() => setShowForm(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white"
            >
              Create Your First Pass
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {guestPasses.map((pass) => (
              <GuestPassCard
                key={pass.id}
                pass={pass}
                onUpdate={() => user && fetchGuestPasses(user.id)}
              />
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
