'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { createClient } from '@/lib/supabase/client'
import { Lock } from 'lucide-react'
import { Button } from '@/components/ui/button'
import Link from 'next/link'

export default function Page() {
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const checkAuth = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (user) {
        // Get user profile to determine role
        const { data: profile } = await supabase
          .from('profiles')
          .select('role')
          .eq('id', user.id)
          .single()

        if (profile?.role === 'resident') {
          router.push('/dashboard/resident')
        } else if (['security', 'admin'].includes(profile?.role || '')) {
          router.push('/dashboard/security')
        }
      }
    }

    checkAuth()
  }, [])

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 flex items-center justify-center p-4">
      <div className="max-w-md w-full text-center">
        {/* Logo */}
        <div className="flex justify-center mb-6">
          <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl flex items-center justify-center">
            <Lock className="w-8 h-8 text-white" />
          </div>
        </div>

        {/* Heading */}
        <h1 className="text-4xl font-bold text-slate-900 mb-2">SecureEntry</h1>
        <p className="text-lg text-slate-600 mb-8">Visitor Management System</p>

        {/* Description */}
        <p className="text-slate-600 mb-8">
          Streamline your residential security with our comprehensive visitor management platform. Manage guest passes, track entry logs, and ensure building safety.
        </p>

        {/* Features */}
        <div className="bg-white rounded-lg border border-slate-200 p-6 mb-8 space-y-4 text-left">
          <div className="flex gap-3">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-slate-900">Easy Guest Passes</h3>
              <p className="text-sm text-slate-600">Create and manage visitor passes with QR codes</p>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-slate-900">Quick Check-in</h3>
              <p className="text-sm text-slate-600">Scan QR codes for fast and secure entry verification</p>
            </div>
          </div>
          <div className="flex gap-3">
            <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0" />
            <div>
              <h3 className="font-semibold text-slate-900">Complete Tracking</h3>
              <p className="text-sm text-slate-600">Monitor all visitor entries and exits in real-time</p>
            </div>
          </div>
        </div>

        {/* CTA Buttons */}
        <div className="space-y-3">
          <Link href="/auth/login" className="block">
            <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 h-auto">
              Sign In
            </Button>
          </Link>
          <Link href="/auth/sign-up" className="block">
            <Button variant="outline" className="w-full py-2 h-auto">
              Create Account
            </Button>
          </Link>
        </div>
      </div>
    </main>
  )
}
