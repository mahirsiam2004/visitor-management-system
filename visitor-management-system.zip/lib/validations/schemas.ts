import { z } from 'zod'

export const createGuestPassSchema = z.object({
  guestName: z.string().min(2, 'Guest name must be at least 2 characters'),
  guestPhone: z.string().optional(),
  visitDate: z.string().refine((date) => {
    const selected = new Date(date)
    const today = new Date()
    today.setHours(0, 0, 0, 0)
    return selected >= today
  }, 'Visit date must be today or in the future'),
  visitTime: z.string().regex(/^\d{2}:\d{2}$/, 'Invalid time format'),
  durationHours: z.number().min(1).max(24, 'Duration must be between 1 and 24 hours'),
  purpose: z.string().min(3, 'Purpose must be at least 3 characters'),
})

export const updateGuestPassSchema = createGuestPassSchema.partial()

export const checkInGuestSchema = z.object({
  guestId: z.string().min(1, 'Guest ID is required'),
  qrToken: z.string().min(1, 'QR token is required'),
})

export const checkOutGuestSchema = z.object({
  entryLogId: z.string().uuid('Invalid entry log ID'),
})

export const updateProfileSchema = z.object({
  fullName: z.string().optional(),
  phoneNumber: z.string().optional(),
  apartmentNumber: z.string().optional(),
})

export type CreateGuestPassInput = z.infer<typeof createGuestPassSchema>
export type UpdateGuestPassInput = z.infer<typeof updateGuestPassSchema>
export type CheckInGuestInput = z.infer<typeof checkInGuestSchema>
export type CheckOutGuestInput = z.infer<typeof checkOutGuestSchema>
export type UpdateProfileInput = z.infer<typeof updateProfileSchema>
