import { v4 as uuidv4 } from 'uuid'

export function generateQRToken(): string {
  return uuidv4()
}

export function generateGuestId(): string {
  return `GUEST-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`
}

export function formatQRData(guestId: string, qrToken: string): string {
  return JSON.stringify({
    id: guestId,
    token: qrToken,
    timestamp: new Date().toISOString(),
  })
}

export function parseQRData(data: string): { id: string; token: string; timestamp: string } | null {
  try {
    return JSON.parse(data)
  } catch {
    return null
  }
}

export function calculateExpiryTime(visitDate: string, visitTime: string, durationHours: number): Date {
  const [year, month, day] = visitDate.split('-').map(Number)
  const [hours, minutes] = visitTime.split(':').map(Number)

  const visitDateTime = new Date(year, month - 1, day, hours, minutes, 0)
  visitDateTime.setHours(visitDateTime.getHours() + durationHours)

  return visitDateTime
}

export function isPassExpired(expiryTime: string): boolean {
  return new Date(expiryTime) < new Date()
}

export function formatDateTime(dateString: string): string {
  const date = new Date(dateString)
  return date.toLocaleString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  })
}

export function formatDate(dateString: string): string {
  const date = new Date(dateString)
  return date.toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  })
}
