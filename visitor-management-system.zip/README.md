# SecureEntry - Visitor Management System

A comprehensive, enterprise-grade visitor management platform for residential buildings. Streamline security, manage guest passes with QR codes, and track all visitor entries and exits in real-time.

## Features

### 🏠 Resident Features
- **Create Guest Passes**: Generate visitor passes with custom duration and purpose
- **QR Code Generation**: Automatic QR code generation for each guest pass
- **QR Code Download**: Download guest pass QR codes as PNG images
- **Pass Management**: View, revoke, or manage all guest passes
- **Real-time Status**: Track the status of each guest pass (valid, expired, revoked)

### 🛡️ Security Guard Features
- **QR Code Scanning**: Use device camera to scan guest QR codes
- **Manual Entry**: Manually enter guest IDs for check-in
- **Check-in/Check-out**: Scan QR codes to manage guest entry and exit
- **Activity Logs**: View real-time entry and exit logs
- **Duration Tracking**: Automatic duration calculation for guest visits

### 👨‍💼 Admin Features
- **User Management**: Manage profiles and assign roles
- **System Analytics**: View comprehensive visitor statistics
- **Guest Pass Management**: Revoke or delete any guest pass
- **Access Control**: Full system administration capabilities

## Tech Stack

- **Frontend**: Next.js 16, React 19, TypeScript
- **Styling**: Tailwind CSS, Shadcn UI components
- **Database**: Supabase PostgreSQL with Row Level Security
- **Authentication**: Supabase Auth with role-based access control
- **QR Code**: react-qr-code for generation, html5-qrcode for scanning
- **Validation**: Zod for schema validation
- **Forms**: React Hook Form with Zod integration
- **Notifications**: Sonner for toast notifications
- **Animations**: Framer Motion

## Database Schema

### Tables

#### profiles
- User profile information
- Fields: id, email, full_name, phone_number, apartment_number, role, created_at, updated_at
- Roles: resident, security, admin

#### guest_passes
- Guest pass records
- Fields: id, guest_id, guest_name, guest_phone, resident_id, apartment_number, visit_date, visit_time, expiry_time, duration_hours, purpose, qr_token, status, created_at, updated_at
- Statuses: valid, expired, revoked

#### entry_logs
- Entry and exit records
- Fields: id, guest_pass_id, security_guard_id, entry_time, exit_time, status, created_at, updated_at
- Statuses: inside, completed

### Row Level Security (RLS)

All tables are protected with RLS policies:
- Users can only access their own data
- Security guards can view all entry logs
- Admins have full access to all data

## Getting Started

### Prerequisites

- Node.js 18+
- pnpm or npm
- Supabase account

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   pnpm install
   ```

3. Set up environment variables in `.env.local`:
   ```
   NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your_supabase_anon_key
   NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL=http://localhost:3000/auth/callback
   ```

4. Run the development server:
   ```bash
   pnpm dev
   ```

5. Open [http://localhost:3000](http://localhost:3000) in your browser

## Project Structure

```
app/
  ├── auth/                  # Authentication pages
  │   ├── login/
  │   ├── sign-up/
  │   ├── callback/
  │   └── error/
  ├── dashboard/             # Protected dashboards
  │   ├── resident/
  │   └── security/
  └── actions/               # Server actions
      └── guest-passes.ts

components/
  ├── ui/                    # Shadcn UI components
  ├── ResidentHeader.tsx     # Resident dashboard header
  ├── SecurityHeader.tsx     # Security guard dashboard header
  ├── CreateGuestPassForm.tsx # Guest pass creation form
  ├── GuestPassCard.tsx      # Guest pass display component
  ├── QRScanner.tsx          # QR code scanner
  └── EntryLogsList.tsx      # Entry logs display

lib/
  ├── supabase/             # Supabase client setup
  ├── utils/                # Utility functions
  └── validations/          # Zod schemas

middleware.ts              # Authentication middleware
```

## User Flows

### Resident Flow
1. Sign up with email, password, apartment number, and phone
2. Create a guest pass with visitor details
3. Download/share the QR code with the visitor
4. View all guest passes and their status
5. Revoke passes if needed

### Security Guard Flow
1. Sign in with email and password
2. Open the QR scanner
3. Scan the visitor's QR code
4. Record entry/exit time
5. View activity logs

### Admin Flow
1. Sign in with admin credentials
2. Access all users and guest passes
3. Manage system-wide settings
4. View comprehensive analytics

## API Endpoints

### Guest Pass Actions
- `createGuestPass()` - Create a new guest pass
- `getGuestPasses()` - Retrieve guest passes with filters
- `updateGuestPassStatus()` - Update pass status (valid/expired/revoked)
- `deleteGuestPass()` - Delete a guest pass
- `checkInGuest()` - Check in a guest via QR scan
- `checkOutGuest()` - Check out a guest

## Security Features

- **Row Level Security**: Database-level access control
- **Role-Based Access Control**: Three-tier user roles
- **Password Hashing**: Supabase handles secure password storage
- **Session Management**: Secure cookie-based sessions
- **QR Token Verification**: Unique tokens for each guest pass
- **Email Confirmation**: Required before account activation

## Deployment

### Vercel (Recommended)

1. Push your code to GitHub
2. Connect your repository to Vercel
3. Set environment variables in Vercel dashboard
4. Deploy

```bash
vercel deploy
```

### Docker

```bash
docker build -t secureentry .
docker run -p 3000:3000 secureentry
```

## Contributing

1. Create a feature branch
2. Make your changes
3. Submit a pull request

## License

MIT License

## Support

For issues and questions, please open an issue on GitHub.

## Roadmap

- [ ] Mobile app for residents
- [ ] SMS/Email notifications
- [ ] Multi-building support
- [ ] Analytics dashboard
- [ ] Export reports (PDF/CSV)
- [ ] Integration with building management systems
- [ ] Two-factor authentication
- [ ] Guest pre-registration

---

**SecureEntry** - Making residential security simple and secure.
